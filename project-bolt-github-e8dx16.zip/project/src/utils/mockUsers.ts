export const mockUsers = [
  {
    email: "joao@teste.com",
    orderCode: "ORD123",
    redirectUrl: "https://instagram.com/joao"
  },
  {
    email: "maria@teste.com",
    orderCode: "ORD456",
    redirectUrl: "https://linkedin.com/in/maria"
  },
  {
    email: "pedro@teste.com",
    orderCode: "ORD789",
    redirectUrl: "https://github.com/pedro"
  }
] as const;