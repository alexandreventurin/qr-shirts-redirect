import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { database } from './config/database.js';
import redirectRoutes from './routes/redirect.js';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    await database.connect();
    console.log('Database connected successfully');

    // CORS configuration
    app.use(cors({
      origin: process.env.CORS_ORIGIN || '*',
      credentials: true
    }));

    // Middleware
    app.use(express.json());
    
    // Health check endpoint - must come before static files
    app.get('/health', (req, res) => {
      res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
      });
    });

    // Static files
    app.use(express.static(path.join(__dirname, '..', 'dist')));
    
    // API routes
    app.use('/', redirectRoutes);

    // Serve index.html for all other routes (SPA support)
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, '..', 'dist', 'index.html'));
    });

    // Error handling middleware
    app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
      console.error('Server error:', err.stack);
      res.status(500).json({ 
        error: 'Internal Server Error',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
      });
    });

    // Start server
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Health check available at http://localhost:${PORT}/health`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();